// BSS isnt strong with Javascript code in each file. It works via Custom Component, but has some issues with the timing of loading the page.
// So some stuff doesn't appear be possible, e.g. $ from jQuery not yet loaded, so custom code for each file
// is aggregated here and checks for specific page/body ids to be triggered.

// read node red json flow
// better not done every page reload, but so it be for now...
var jsonFlow = null;
$(function(){
	
	// var jqxhr = $.getJSON( "http://localhost:8000/assets/resources/node-red-flows.json", function() {
	//   console.log( "success" );
	// });
	
	
	// this appears to be evil - sync call in main worker
	/*
	jsonFlow = $.parseJSON(
	    $.ajax(
	        {
	           url: "assets/resources/node-red-flows.json",
	           async: false,
					 cache: false,
	           dataType: 'json'
	        }
	    ).responseText
	);*/
	// var abc = $.ajax(
	//         {
	//            url: "http://localhost:3001/assets/resources/node-red-flows.json",
	//
	//            // url: "assets/resources/node-red-flows.json",
	// 		   // headers: {  'Access-Control-Allow-Origin': '*' },
	//
	//            async: false,
	// 		   crossDomain: true,
	// 				 cache: false,
	//            dataType: 'json'
	//         }
	//     ).responseText;
	//
	//
	//



	// REPLACE   with nothing and ' with '. aso get rid of weird workspaceXml line
		var abc = `
	[
	    {
	        "id": "5d631fe7cdf8e7c7",
	        "type": "tab",
	        "label": "BHI Oxygen Checklist",
	        "disabled": false,
	        "info": "",
	        "env": []
	    },
	    {
	        "id": "19bf9148220907d9",
	        "type": "case-start",
	        "z": "5d631fe7cdf8e7c7",
	        "name": "Daily visual inspection",
	        "includename": "",
	        "includeidentifier": "",
	        "program": "",
	        "expression": "",
	        "x": 140,
	        "y": 40,
	        "wires": [
	            [
	                "6f17a644c1e7d9ae"
	            ]
	        ]
	    },
	    {
	        "id": "6f17a644c1e7d9ae",
	        "type": "question-select",
	        "z": "5d631fe7cdf8e7c7",
	        "name": "",
	        "label": "Remove any combustile materials in or near plant",
	        "scope": "encounter",
	        "key": "",
	        "behavior": "single",
	        "devices": [
	            {
	                "sid": "Done"
	            },
	            {
	                "sid": "Not done"
	            },
	            {
	                "sid": "Not answered"
	            }
	        ],
	        "x": 160,
	        "y": 80,
	        "wires": [
	            [
	                "6be0b3e5f60cdf69"
	            ]
	        ]
	    },
	    {
	        "id": "d8b1016e171f241e",
	        "type": "case-end",
	        "z": "5d631fe7cdf8e7c7",
	        "name": "",
	        "x": 280,
	        "y": 520,
	        "wires": []
	    },
	    {
	        "id": "5a932d8a1eeb35f6",
	        "type": "case-start",
	        "z": "5d631fe7cdf8e7c7",
	        "name": "Daily data collection",
	        "includename": "",
	        "includeidentifier": "",
	        "program": "",
	        "expression": "",
	        "x": 550,
	        "y": 80,
	        "wires": [
	            [
	                "a922214fb741c1c3"
	            ]
	        ]
	    },
	    {
	        "id": "e16fefa90ca26131",
	        "type": "case-end",
	        "z": "5d631fe7cdf8e7c7",
	        "name": "",
	        "x": 640,
	        "y": 240,
	        "wires": []
	    },
	    {
	        "id": "45998d70a3694c3e",
	        "type": "question-primitive",
	        "z": "5d631fe7cdf8e7c7",
	        "name": "dewpoint",
	        "label": "Pressure Dew Point Temperatur (deg C)",
	        "scope": "encounter",
	        "key": "dewpoint",
	        "datatype": "integer",
	        "optional": true,
	        "x": 580,
	        "y": 200,
	        "wires": [
	            [
	                "e16fefa90ca26131"
	            ]
	        ]
	    },
	    {
	        "id": "6be0b3e5f60cdf69",
	        "type": "question-select",
	        "z": "5d631fe7cdf8e7c7",
	        "name": "",
	        "label": "Ensure that filters/covers are in place",
	        "scope": "encounter",
	        "key": "",
	        "behavior": "single",
	        "devices": [
	            {
	                "sid": "Done"
	            },
	            {
	                "sid": "Not done"
	            },
	            {
	                "sid": "Not answered"
	            }
	        ],
	        "x": 160,
	        "y": 120,
	        "wires": [
	            [
	                "16b7fab950aa0a89"
	            ]
	        ]
	    },
	    {
	        "id": "16b7fab950aa0a89",
	        "type": "question-select",
	        "z": "5d631fe7cdf8e7c7",
	        "name": "",
	        "label": "Are all ventilation systems working?",
	        "scope": "encounter",
	        "key": "",
	        "behavior": "single",
	        "devices": [
	            {
	                "sid": "Yes"
	            },
	            {
	                "sid": "No"
	            },
	            {
	                "sid": "Not answered"
	            }
	        ],
	        "x": 200,
	        "y": 160,
	        "wires": [
	            [
	                "7a5cec5a5539b893"
	            ]
	        ]
	    },
	    {
	        "id": "7a5cec5a5539b893",
	        "type": "question-select",
	        "z": "5d631fe7cdf8e7c7",
	        "name": "",
	        "label": "Empty condensate container (if equipped)",
	        "scope": "encounter",
	        "key": "",
	        "behavior": "single",
	        "devices": [
	            {
	                "sid": "Done"
	            },
	            {
	                "sid": "Not done"
	            },
	            {
	                "sid": "Not answered"
	            }
	        ],
	        "x": 160,
	        "y": 200,
	        "wires": [
	            [
	                "4a93740eca1e52e1"
	            ]
	        ]
	    },
	    {
	        "id": "4a93740eca1e52e1",
	        "type": "question-select",
	        "z": "5d631fe7cdf8e7c7",
	        "name": "",
	        "label": "Is the air dryer condensate draining correctly?",
	        "scope": "encounter",
	        "key": "",
	        "behavior": "single",
	        "devices": [
	            {
	                "sid": "Yes"
	            },
	            {
	                "sid": "No"
	            },
	            {
	                "sid": "Not answered"
	            }
	        ],
	        "x": 200,
	        "y": 240,
	        "wires": [
	            [
	                "9a00b1080704e39b"
	            ]
	        ]
	    },
	    {
	        "id": "9a00b1080704e39b",
	        "type": "question-select",
	        "z": "5d631fe7cdf8e7c7",
	        "name": "",
	        "label": "Is the compressor condensate draining correctly?",
	        "scope": "encounter",
	        "key": "",
	        "behavior": "single",
	        "devices": [
	            {
	                "sid": "Yes"
	            },
	            {
	                "sid": "No"
	            },
	            {
	                "sid": "Not answered"
	            }
	        ],
	        "x": 200,
	        "y": 280,
	        "wires": [
	            [
	                "57a953f908fbabde"
	            ]
	        ]
	    },
	    {
	        "id": "57a953f908fbabde",
	        "type": "question-select",
	        "z": "5d631fe7cdf8e7c7",
	        "name": "",
	        "label": "Is the air dryer condensate draining correctly?",
	        "scope": "encounter",
	        "key": "",
	        "behavior": "single",
	        "devices": [
	            {
	                "sid": "Yes"
	            },
	            {
	                "sid": "No"
	            },
	            {
	                "sid": "Not answered"
	            }
	        ],
	        "x": 200,
	        "y": 320,
	        "wires": [
	            [
	                "fb0d3bdea426be9e"
	            ]
	        ]
	    },
	    {
	        "id": "fb0d3bdea426be9e",
	        "type": "question-select",
	        "z": "5d631fe7cdf8e7c7",
	        "name": "",
	        "label": "Are the in-line filters condensates draining correctly?",
	        "scope": "encounter",
	        "key": "",
	        "behavior": "single",
	        "devices": [
	            {
	                "sid": "Yes"
	            },
	            {
	                "sid": "No"
	            },
	            {
	                "sid": "Not answered"
	            }
	        ],
	        "x": 200,
	        "y": 360,
	        "wires": [
	            [
	                "8be47dda28bf2c22"
	            ]
	        ]
	    },
	    {
	        "id": "8be47dda28bf2c22",
	        "type": "question-select",
	        "z": "5d631fe7cdf8e7c7",
	        "name": "",
	        "label": "Is the compressor oil level acceptable?",
	        "scope": "encounter",
	        "key": "",
	        "behavior": "single",
	        "devices": [
	            {
	                "sid": "Yes"
	            },
	            {
	                "sid": "No"
	            },
	            {
	                "sid": "Not answered"
	            }
	        ],
	        "x": 200,
	        "y": 400,
	        "wires": [
	            [
	                "6d43b67a26c9dac8"
	            ]
	        ]
	    },
	    {
	        "id": "6d43b67a26c9dac8",
	        "type": "question-select",
	        "z": "5d631fe7cdf8e7c7",
	        "name": "",
	        "label": "Sweep/Mop floor and dust surfaces",
	        "scope": "encounter",
	        "key": "",
	        "behavior": "single",
	        "devices": [
	            {
	                "sid": "Done"
	            },
	            {
	                "sid": "Not done"
	            },
	            {
	                "sid": "Not answered"
	            }
	        ],
	        "x": 180,
	        "y": 440,
	        "wires": [
	            [
	                "b73ab6e20e44d754"
	            ]
	        ]
	    },
	    {
	        "id": "b73ab6e20e44d754",
	        "type": "question-select",
	        "z": "5d631fe7cdf8e7c7",
	        "name": "",
	        "label": "Are there any oil leaks at the bottom of the compressor?",
	        "scope": "encounter",
	        "key": "",
	        "behavior": "single",
	        "devices": [
	            {
	                "sid": "Yes"
	            },
	            {
	                "sid": "No"
	            },
	            {
	                "sid": "Not answered"
	            }
	        ],
	        "x": 200,
	        "y": 480,
	        "wires": [
	            [
	                "d8b1016e171f241e"
	            ]
	        ]
	    },
	    {
	        "id": "72f3c2735828bd61",
	        "type": "http response",
	        "z": "5d631fe7cdf8e7c7",
	        "name": "",
	        "statusCode": "",
	        "headers": {},
	        "x": 630,
	        "y": 340,
	        "wires": []
	    },
	    {
	        "id": "687405a06cb4dbb0",
	        "type": "question-primitive",
	        "z": "5d631fe7cdf8e7c7",
	        "name": "purity",
	        "label": "Oxygen Purity (%)",
	        "scope": "encounter",
	        "key": "purity",
	        "datatype": "integer",
	        "optional": true,
	        "x": 570,
	        "y": 160,
	        "wires": [
	            [
	                "45998d70a3694c3e"
	            ]
	        ]
	    },
	    {
	        "id": "a922214fb741c1c3",
	        "type": "question-select",
	        "z": "5d631fe7cdf8e7c7",
	        "name": "location",
	        "label": "Country & facility",
	        "scope": "encounter",
	        "key": "location",
	        "behavior": "single",
	        "devices": [
	            {
	                "sid": "Malawi - Partners in Hope"
	            },
	            {
	                "sid": "Malawi - Neno District Hospital"
	            },
	            {
	                "sid": "Malawi - Neno Parish"
	            }
	        ],
	        "x": 580,
	        "y": 120,
	        "wires": [
	            [
	                "687405a06cb4dbb0"
	            ]
	        ]
	    }
	]		
	`;
		 // console.log('YYY abc ' + abc);
		jsonFlow = $.parseJSON(abc);
});

function toUpperCaseFirstLetter(string)  {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

function getUrlParam(param) {
	let searchParams = new URLSearchParams(window.location.search);
	return searchParams.get(param);
}

function formatDate(date) {
	const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
	return ("0" + date.getDate()).slice(-2) + "-" + monthNames[date.getMonth()] + "-" + date.getFullYear();
}

function labelFor(node) {
	if (node.label === undefined || node.label.trim() === '') {
		if (node.name === undefined || node.name.trim() === '') {
			return node.type;
		}
		return node.name;
	}
	return node.label;
}

function keyFor(node) {
	if (node.key === undefined || node.key.trim() === '') {
		if (node.name === undefined || node.name.trim() === '') {
			return node.type;
		}
		return node.name;
	} else {
		return node.key;
	}
}

// ---------------------------------------------------------
// common onload stuff for pages

function processPageDemographicAttribute() {
	$('#alphapad').addClass('d-none');
	$('#keypad').addClass('d-none');
	$('#datepad').addClass('d-none');
	$('#booleanpad').addClass('d-none');
	let nodeid = getUrlParam('nodeid');
 	var node = nodeById(jsonFlow, nodeid);
	$('#input-label').contents().last().replaceWith(node.label);
	switch (node.datatype) {
		case 'decimal':
			$('#keypad-dot').prop('disabled', false);
			$('#keypad').removeClass('d-none');
			break;
		case 'integer':
			$('#keypad-dot').prop('disabled', true);
			$('#keypad').removeClass('d-none');
			break;
		case 'text':
		case 'string':
			$('#alphapad').removeClass('d-none');
			break;
		case 'date':
		case 'time':
		case 'dateTime':
			$('#datepad').removeClass('d-none');
			break;
		case 'boolean':
			$('#booleanpad').removeClass('d-none');
			break;
	}
}

// ---------------------------------------------------------
// common button handlers

function defaultButtonAlphapad(e) {
	if (e.target.id.startsWith("alphapad-bksp")) {
		document.getElementById('input').value = document.getElementById('input').value.substring(0, document.getElementById('input').value.length-1);
	} else if (e.target.id.startsWith("alphapad-dash")) {
		document.getElementById('input').value += '-';
	} else if (e.target.id.startsWith("alphapad-quote")) {
		document.getElementById('input').value += '\'';
	} else if (e.target.id.startsWith("alphapad-space")) {
		document.getElementById('input').value += ' ';
	} else if (e.target.id.startsWith("alphapad-")) {
		document.getElementById('input').value += e.target.id.substring(9);
		document.getElementById('input').value = toUpperCaseFirstLetter(document.getElementById('input').value);
	}
}

function defaultButtonKeypad(e) {
	if (e.target.id.startsWith("keypad-bksp")) {
		document.getElementById('input').value = document.getElementById('input').value.substring(0, document.getElementById('input').value.length-1);
	} else if (e.target.id.startsWith("keypad-dot")) {
		document.getElementById('input').value += '.';
	} else if (e.target.id.startsWith("keypad-")) {
		document.getElementById('input').value += e.target.id.substring(7);
	}
}

function defaultButtonDatepad(e) {
	if (e.target.id.startsWith("keypad-bksp")) {
		document.getElementById('year').value = document.getElementById('year').value.substring(0, document.getElementById('year').value.length-1);
	} else if (e.target.id.startsWith("keypad-dot")) {
		document.getElementById('year').value += '.';
	} else if (e.target.id.startsWith("keypad-")) {
		document.getElementById('year').value += e.target.id.substring(7);
	} else if (e.target.id.startsWith("monthpad-")) {
		document.getElementById('month').value = e.target.id.substring(9);
		document.getElementById('input').value = document.getElementById('year').value + '-' + document.getElementById('month').value + '-' + document.getElementById('day').value;
	} else if (e.target.id.startsWith("day-")) {
		document.getElementById('day').value = e.target.id.substring(4);
		document.getElementById('input').value = document.getElementById('year').value + '-' + document.getElementById('month').value + '-' + document.getElementById('day').value;
	}
}

function defaultButtonBooleanpad(e) {
	if (e.target.id.startsWith("booleanpad-yes")) {
		document.getElementById('input').value = 'Yes';
	} else if (e.target.id.startsWith("booleanpad-no")) {
		document.getElementById('input').value = 'No';
	}
}

// ---------------------------------------------------------
// register event handlers
$(function(){
	// change active class based on selection in all list-groups; currently prevents multiselect
	$('.list-group li').click(function(e) {
		e.preventDefault();
		$that = $(this);
		$that.toggleClass('active');
	});
	$('.list-group:not(.multiple) li').click(function(e) {
		e.preventDefault();
		$that = $(this);
		$that.parent().find('li').removeClass('active');
		$that.addClass('active');
		if($('html').is('#page-current-address') || $('html').is('#page-home-address')){
	    // processPageCheckedInPatientsList();
			switch($that.parent()[0].id) {
				case "list-region":
					document.getElementById('input-region').value = e.currentTarget.childNodes[0].innerText;
					break;
				case "list-district":
					document.getElementById('input-district').value = e.currentTarget.childNodes[0].innerText;
					break;
				case "list-ta":
					document.getElementById('input-ta').value = e.currentTarget.childNodes[0].innerText;
					break;
				case "list-village":
					document.getElementById('input-village').value = e.currentTarget.childNodes[0].innerText;
					break;
			}
		}
	});

	// load onload functions if page provides them
	// https://api.jquery.com/jQuery.getScript/
	var pageId = $('html').attr('id');
	// if (pageId.startsWith('page-')) {
	var pageName = pageId.substring(5, pageId.length);
	var onLoadFunctionName = pageName.replace( /-([a-z])/ig, function( all, letter ) {
		return letter.toUpperCase();
	});
	var onLoadFunctionName = onLoadFunctionName[0].toUpperCase() + onLoadFunctionName.slice(1);
	if (eval("typeof " + 'onLoad' + onLoadFunctionName) === 'function') {
		console.log('calling ' + 'onLoad' + onLoadFunctionName);
		// loadCurrentPatient(function() {});
		// loadCurrentEncounter(function() {});
		self['onLoad' + onLoadFunctionName]();
	} else {
		// make sure that at least the header is set
		// loadCurrentPatient(function() {});
		console.log("No onLoad function provided by module " + onLoadFunctionName);
	}
	// if (pageId.startsWith('page-')) {
	// 	pageName = pageId.substring(5, pageId.length);
	// 	$.get("assets/client-js/bricks/" + pageName + ".js")
	// 		.done(function() {
	// 			$.getScript( "assets/client-js/bricks/" + pageName + ".js" )
	// 				.done(function( script, textStatus ) {
	// 					console.log("Loading page-specific script file: " + pageName );
	// 					// processPageFindPatient();
	// 					onLoadFunctionName = pageName.replace( /-([a-z])/ig, function( all, letter ) {
	// 						return letter.toUpperCase();
	// 					});
	// 					onLoadFunctionName = onLoadFunctionName[0].toUpperCase() + onLoadFunctionName.slice(1);
	// 					if (eval("typeof " + 'onLoad' + onLoadFunctionName) === 'function') {
	// 						console.log('calling ' + 'onLoad' + onLoadFunctionName);
	// 						// loadCurrentPatient(function() {});
	// 						// loadCurrentEncounter(function() {});
	// 						self['onLoad' + onLoadFunctionName]();
	// 					} else {
	// 						// make sure that at least the header is set
	// 						// loadCurrentPatient(function() {});
	// 						console.log("No onLoad function provided by module " + onLoadFunctionName);
	// 					}
	// 				})
	// 				.fail(function( jqxhr, settings, exception ) {
	// 					console.log("Loading FAILED for page-specific script file: " + pageName );
	// 				});
	// 			})
	// 		.fail(function() {
	// 			// make sure that at least the header is set
	// 			// loadCurrentPatient(function() {});
	// 			console.log("No page-specific script file found: " + pageName );
	// 		})
	// }

});

// respond to keys pressed
$(document).keypress(function(e) {
	// event.preventDefault();
	if ($('#navigation-next').prop('disabled') === false) {
		if(e.which == 13) {
		// enter pressed
			nextPressed(e);
		}
	};
});

// repsond to buttons clicked
$('.btn').click(function(e) {

	// navigation buttons in footer
	switch (e.currentTarget.id) {
		case "navigation-next":
			nextPressed(e);
			break;
		case "navigation-back":
			// console.log("previous brick: " + window.location.pathname);
			// location = getPreviousBrick(window.location.pathname) + ".html";
			window.history.back();
			break;
		case "navigation-clear":
			// loadCurrentPatient from previous step
			location.reload();
			break;
		case "navigation-finish":
			finishPressed(e);
			break;
		case "navigation-cancel":
			location = 'flow-select.html';
			break;
	}
});

function nextPressed(e) {
	// prepare module specific button handlers
	pageId = $("html")[0].id;
	moduleName = "";
	if (pageId.startsWith('page-')) {
		pageName = pageId.substring(5, pageId.length);
		moduleName = pageName.replace( /-([a-z])/ig, function( all, letter ) {
			return letter.toUpperCase();
		});
		moduleName = moduleName[0].toUpperCase() + moduleName.slice(1);
	}

	let nodeid = getUrlParam('nodeid');
	let stepid = getUrlParam('stepid');
	stepid++;
	let next = nextNode(jsonFlow, nodeById(jsonFlow, nodeid))[0];
	if (typeof next === 'undefined') {
		alert('Missing outgoing connection in workflow definition!');
	}
	// store
	let newUrl = next.type + ".html?stepid=" + stepid + "&nodeid=" + next.id;
	// console.log(newUrl);

	console.log(newUrl + ' ' + eval("typeof " + 'hookNext' + moduleName));
	if (eval("typeof " + 'hookNext' + moduleName) === 'function') {
		console.log('calling ' + 'hookNext' + moduleName);
		self['hookNext' + moduleName](e);
		updateCurrentEncounter(currentEncounter);
		updateCurrentPatient(currentPatient);
	} else {
		console.log("No hookNext function provided by module " + moduleName);
	}

	location= newUrl;
}

function finishPressed(e) {
	pageId = $("html")[0].id;
	moduleName = "";
	if (pageId.startsWith('page-')) {
		pageName = pageId.substring(5, pageId.length);
		moduleName = pageName.replace( /-([a-z])/ig, function( all, letter ) {
			return letter.toUpperCase();
		});
		moduleName = moduleName[0].toUpperCase() + moduleName.slice(1);
	}
	
	console.log(eval("typeof " + 'hookFinish' + moduleName));
	if (eval("typeof " + 'hookFinish' + moduleName) === 'function') {
		console.log('calling ' + 'hookFinish' + moduleName);
		self['hookFinish' + moduleName](e);
		// updateCurrentEncounter(currentEncounter);
		// updateCurrentPatient(currentPatient);
	} else {
		console.log("No hookFinish function provided by module " + moduleName);
	}
	// location = '/';
	// location = 'flow-select.html';

	/*
	// TODO this should move somewhere more appropriate
	if (!jQuery.isEmptyObject(currentEncounter)) { 
		// 'normal encounter'
		$.ajax({
		    type: "POST",
		    url: "/patients/" + currentPatient.id + "/encounters/",
		    // The key needs to match your method's input parameter (case-sensitive).
		    data: JSON.stringify(currentEncounter),
		    contentType: "application/json; charset=utf-8",
		    dataType: "json",
		    success: function(data){
				// alert('Data saved');
				location = 'flow-select.html';
			},
		    error: function(errMsg) {
				console.log("errMsg");
				console.log(JSON.stringify(errMsg));
		        alert(errMsg);
		    }
		});
	}
	location = 'flow-select.html';
	*/
}