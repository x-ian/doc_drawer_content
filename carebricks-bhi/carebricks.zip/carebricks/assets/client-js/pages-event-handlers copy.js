// BSS isnt strong with Javascript code in each file. It works via Custom Component, but has some issues with the timing of loading the page.
// So some stuff doesn't appear be possible, e.g. $ from jQuery not yet loaded, so custom code for each file
// is aggregated here and checks for specific page/body ids to be triggered.

// read node red json flow
// better not done every page reload, but so it be for now...
var jsonFlow = null;
$(function(){
	
	// var jqxhr = $.getJSON( "http://localhost:8000/assets/resources/node-red-flows.json", function() {
	//   console.log( "success" );
	// });
	
	
	// this appears to be evil - sync call in main worker
	/*
	jsonFlow = $.parseJSON(
	    $.ajax(
	        {
	           url: "assets/resources/node-red-flows.json",
	           async: false,
					 cache: false,
	           dataType: 'json'
	        }
	    ).responseText
	);*/
	// var abc = $.ajax(
	//         {
	//            url: "http://localhost:3001/assets/resources/node-red-flows.json",
	//
	//            // url: "assets/resources/node-red-flows.json",
	// 		   // headers: {  'Access-Control-Allow-Origin': '*' },
	//
	//            async: false,
	// 		   crossDomain: true,
	// 				 cache: false,
	//            dataType: 'json'
	//         }
	//     ).responseText;
	//
	//
	//



	// REPLACE   with nothing and ' with '. aso get rid of weird workspaceXml line
		var abc = `

		[
			{
				"id": "854eb41fd550294f",
				"type": "tab",
				"label": "Cardiology - New-born oximetry screening",
				"disabled": false,
				"info": "",
				"env": []
			},
			{
				"id": "efb40176baf7f7da",
				"type": "tab",
				"label": "HIV - Ascertainment of HIV exposure / infection in children under 24 months",
				"disabled": false,
				"info": "",
				"env": []
			},
			{
				"id": "2297acf6.e98c64",
				"type": "tab",
				"label": "Diagnosing Childhood Malaria",
				"disabled": false,
				"info": ""
			},
			{
				"id": "5d901e35.d089c",
				"type": "tab",
				"label": "OpenMRS RefApp Vitals",
				"disabled": false,
				"info": ""
			},
			{
				"id": "e720fdd.1c9ee",
				"type": "tab",
				"label": "OpenMRS RefApp Vitals Full",
				"disabled": false,
				"info": ""
			},
			{
				"id": "7bf38ac1.088444",
				"type": "careflow-config",
				"environment": "xian",
				"runtime_flow_path": "/Users/xian/projects/data-first-emr/care-bricks/resources/node-red-flows.json"
			},
			{
				"id": "fa608b60.1bd338",
				"type": "careflow-config",
				"environment": "ghii amazon ec2",
				"runtime_flow_path": "/home/cneumann/workflow-poc-emr/resources/node-red-flows.json"
			},
			{
				"id": "f5365baa483edb1d",
				"type": "case-start",
				"z": "854eb41fd550294f",
				"name": "",
				"includename": "",
				"includeidentifier": "",
				"program": "",
				"expression": "",
				"x": 160,
				"y": 60,
				"wires": [
					[
						"57a953eed667a1c6"
					]
				]
			},
			{
				"id": "57a953eed667a1c6",
				"type": "question-primitive",
				"z": "854eb41fd550294f",
				"name": "Pulse oximetry of RH",
				"label": "",
				"scope": "demographic",
				"key": "rh",
				"datatype": "integer",
				"optional": "",
				"x": 220,
				"y": 120,
				"wires": [
					[
						"a2d139d34a210696"
					]
				]
			},
			{
				"id": "a2d139d34a210696",
				"type": "question-primitive",
				"z": "854eb41fd550294f",
				"name": "Pulse oximetry of 1 foot",
				"label": "",
				"scope": "demographic",
				"key": "foot",
				"datatype": "integer",
				"optional": "",
				"x": 450,
				"y": 120,
				"wires": [
					[
						"dbba6011d99056eb"
					]
				]
			},
			{
				"id": "dbba6011d99056eb",
				"type": "function",
				"z": "854eb41fd550294f",
				"name": "function 1",
				"func": "var rh = parseInt(currentPatient.rh); var foot = parseInt(currentPatient.foot);  var diff = 100 * Math.abs((rh - foot) / ((rh + foot) / 2)); currentPatient['diff'] = diff; currentPatient['result'] = 'UNKNOWN';  if (rh <= 89 || foot <= 89) {     currentPatient['xa'] = '1';     currentPatient['result'] = 'FAIL'; } else {     if ((rh >= 90 && rh <= 94) || (foot >= 90 && foot <= 94)) {         currentPatient['xb'] = '2';         currentPatient['result'] = 'RETEST';     } else {         if (diff >= 4) {             currentPatient['xc'] = '3';             currentPatient['result'] = 'RETEST';         } else {             if (rh >= 95 && foot >= 95 && diff <= 2) {                 currentPatient['xd'] = '4';                 currentPatient['result'] = 'PASS';             }         }     } }  updateCurrentPatient(currentPatient); ",
				"outputs": 1,
				"noerr": 1,
				"initialize": "",
				"finalize": "",
				"libs": [],
				"x": 200,
				"y": 200,
				"wires": [
					[
						"251dfaed53089611"
					]
				]
			},
			{
				"id": "251dfaed53089611",
				"type": "switch",
				"z": "854eb41fd550294f",
				"name": "",
				"property": "payload",
				"propertyType": "msg",
				"rules": [
					{
						"t": "eq",
						"v": "currentPatient.result=='FAIL'",
						"vt": "jsonata"
					},
					{
						"t": "eq",
						"v": "currentPatient.result=='RETEST'",
						"vt": "jsonata"
					},
					{
						"t": "eq",
						"v": "currentPatient.result=='PASS'",
						"vt": "jsonata"
					},
					{
						"t": "eq",
						"v": "currentPatient.result=='UNKNOWN'",
						"vt": "jsonata"
					}
				],
				"checkall": "true",
				"repair": false,
				"outputs": 4,
				"x": 350,
				"y": 200,
				"wires": [
					[
						"6f861f483127e78e"
					],
					[
						"c33189cbb8863667"
					],
					[
						"4d4ffd4ecccd86ff"
					],
					[
						"4056c2ad58c0dc3d"
					]
				]
			},
			{
				"id": "8b7d6eb608c4ba56",
				"type": "case-end",
				"z": "854eb41fd550294f",
				"name": "",
				"x": 800,
				"y": 400,
				"wires": []
			},
			{
				"id": "6f861f483127e78e",
				"type": "summary",
				"z": "854eb41fd550294f",
				"name": "",
				"x": 520,
				"y": 160,
				"wires": [
					[
						"8b7d6eb608c4ba56"
					]
				],
				"info": "<h1>Measurement 1 FAILED</h1> <h3>Action: Do not repeat pulse oximetry screening, refer for immediate assessment</h3>"
			},
			{
				"id": "c33189cbb8863667",
				"type": "summary",
				"z": "854eb41fd550294f",
				"name": "",
				"x": 520,
				"y": 280,
				"wires": [
					[
						"9e10e931791db17f"
					]
				],
				"info": "<h1>Measurement 1 RETEST</h1> <h3>Action: Repeat pulse oximetry measurements in 1 hour</h3>"
			},
			{
				"id": "4d4ffd4ecccd86ff",
				"type": "summary",
				"z": "854eb41fd550294f",
				"name": "",
				"x": 520,
				"y": 200,
				"wires": [
					[
						"8b7d6eb608c4ba56"
					]
				],
				"info": "<h1>Measurement 1 PASS</h1> <h3>Action: Do not repeat pulse oximetry screening, provide normal newborn care</h3>"
			},
			{
				"id": "4056c2ad58c0dc3d",
				"type": "summary",
				"z": "854eb41fd550294f",
				"name": "",
				"x": 520,
				"y": 240,
				"wires": [
					[
						"8b7d6eb608c4ba56"
					]
				],
				"info": "<h1>Measurement 1 with UNKNOWN result</h1> <h3>Action: Check input variables</h3>"
			},
			{
				"id": "9e10e931791db17f",
				"type": "question-primitive",
				"z": "854eb41fd550294f",
				"name": "Pulse oximetry of RH #2",
				"label": "",
				"scope": "demographic",
				"key": "rh2",
				"datatype": "integer",
				"optional": "",
				"x": 230,
				"y": 340,
				"wires": [
					[
						"82fae0fbd9a5d1ec"
					]
				]
			},
			{
				"id": "82fae0fbd9a5d1ec",
				"type": "question-primitive",
				"z": "854eb41fd550294f",
				"name": "Pulse oximetry of 1 foot #2",
				"label": "",
				"scope": "demographic",
				"key": "foot2",
				"datatype": "integer",
				"optional": "",
				"x": 480,
				"y": 340,
				"wires": [
					[
						"e0515aa9474f56a0"
					]
				]
			},
			{
				"id": "e0515aa9474f56a0",
				"type": "function",
				"z": "854eb41fd550294f",
				"name": "function 2",
				"func": "var rh2 = parseInt(currentPatient.rh2); var foot2 = parseInt(currentPatient.foot2);  var diff2 = 100 * Math.abs((rh2 - foot2) / ((rh2 + foot2) / 2)); currentPatient['diff2'] = diff2; currentPatient['result2'] = 'UNKNOWN';      if (rh2 <= 94 || foot2 <= 94) {         currentPatient['result2'] = 'FAIL';     } else {         if (diff2 >= 4) {             currentPatient['result2'] = 'FAIL';         } else {             if (rh2 >= 95 && foot2 >= 95 && diff2 <= 2) {                 currentPatient['result2'] = 'PASS';             }         }     }   updateCurrentPatient(currentPatient); ",
				"outputs": 1,
				"noerr": 1,
				"initialize": "",
				"finalize": "",
				"libs": [],
				"x": 200,
				"y": 440,
				"wires": [
					[
						"6bd3879d8c362146"
					]
				]
			},
			{
				"id": "6bd3879d8c362146",
				"type": "switch",
				"z": "854eb41fd550294f",
				"name": "",
				"property": "payload",
				"propertyType": "msg",
				"rules": [
					{
						"t": "eq",
						"v": "currentPatient.result2=='FAIL'",
						"vt": "jsonata"
					},
					{
						"t": "eq",
						"v": "currentPatient.result2=='PASS'",
						"vt": "jsonata"
					},
					{
						"t": "eq",
						"v": "currentPatient.result2=='UNKNOWN'",
						"vt": "jsonata"
					}
				],
				"checkall": "true",
				"repair": false,
				"outputs": 3,
				"x": 350,
				"y": 440,
				"wires": [
					[
						"544e1f4c62f471a6"
					],
					[
						"56c0544fe2a86ffa"
					],
					[
						"754ccd405af75323"
					]
				]
			},
			{
				"id": "56c0544fe2a86ffa",
				"type": "summary",
				"z": "854eb41fd550294f",
				"name": "",
				"x": 520,
				"y": 440,
				"wires": [
					[
						"8b7d6eb608c4ba56"
					]
				],
				"info": "<h1>Measurement 2 PASS</h1> <h3>Action: Do not repeat pulse oximetry screening, provide normal newborn care</h3>"
			},
			{
				"id": "544e1f4c62f471a6",
				"type": "summary",
				"z": "854eb41fd550294f",
				"name": "",
				"x": 520,
				"y": 400,
				"wires": [
					[
						"8b7d6eb608c4ba56"
					]
				],
				"info": "<h1>Measurement 2 FAILED</h1> <h3>Action: Do not repeat pulse oximetry screening, refer for immediate assessment</h3>"
			},
			{
				"id": "754ccd405af75323",
				"type": "summary",
				"z": "854eb41fd550294f",
				"name": "",
				"x": 520,
				"y": 480,
				"wires": [
					[
						"8b7d6eb608c4ba56"
					]
				],
				"info": "<h1>Measurement 2 with UNKNOWN result</h1> <h3>Action: Check input variables</h3>"
			},
			{
				"id": "ebd63b9d14137885",
				"type": "case-start",
				"z": "efb40176baf7f7da",
				"name": "Mother with child under 24 months",
				"includename": "",
				"includeidentifier": "",
				"program": "",
				"expression": "",
				"x": 140,
				"y": 180,
				"wires": [
					[
						"60f83c662ce3fbdf"
					]
				]
			},
			{
				"id": "60f83c662ce3fbdf",
				"type": "switch-manual",
				"z": "efb40176baf7f7da",
				"name": "Mother last test",
				"property": "payload",
				"propertyType": "msg",
				"rules": [
					{
						"t": "eq",
						"v": "Mother never tested / negative before delivery",
						"vt": "str"
					},
					{
						"t": "eq",
						"v": "Mother last positive (any time)",
						"vt": "str"
					},
					{
						"t": "eq",
						"v": "Mother tested neative at / after delivery",
						"vt": "str"
					}
				],
				"checkall": "true",
				"repair": false,
				"outputs": 3,
				"x": 220,
				"y": 240,
				"wires": [
					[
						"1102bea819991ab5"
					],
					[
						"f62d525372738815"
					],
					[
						"3d12f1490d54f79c"
					]
				]
			},
			{
				"id": "021eabe05b363040",
				"type": "case-end",
				"z": "efb40176baf7f7da",
				"name": "",
				"x": 1160,
				"y": 100,
				"wires": []
			},
			{
				"id": "1102bea819991ab5",
				"type": "summary",
				"z": "efb40176baf7f7da",
				"name": "Rapid test (serial) for mother",
				"x": 460,
				"y": 100,
				"wires": [
					[
						"f62d525372738815"
					]
				],
				"info": "<h1> Rapid test (serial) for mother</h1>"
			},
			{
				"id": "f62d525372738815",
				"type": "switch-manual",
				"z": "efb40176baf7f7da",
				"name": "Mother test status",
				"property": "payload",
				"propertyType": "msg",
				"rules": [
					{
						"t": "eq",
						"v": "Mother Negative",
						"vt": "str"
					},
					{
						"t": "eq",
						"v": "Mother Positive",
						"vt": "str"
					}
				],
				"checkall": "true",
				"repair": false,
				"outputs": 2,
				"x": 710,
				"y": 120,
				"wires": [
					[
						"9be6220aeae6653f"
					],
					[
						"d182f07a123e3ac0"
					]
				]
			},
			{
				"id": "9be6220aeae6653f",
				"type": "summary",
				"z": "efb40176baf7f7da",
				"name": "Continue regular U5 visit",
				"x": 950,
				"y": 100,
				"wires": [
					[
						"021eabe05b363040"
					]
				],
				"info": "<h1>Continue regular U5 visit</h1>"
			},
			{
				"id": "d182f07a123e3ac0",
				"type": "switch-manual",
				"z": "efb40176baf7f7da",
				"name": "Recent",
				"property": "payload",
				"propertyType": "msg",
				"rules": [
					{
						"t": "eq",
						"v": "12 months +",
						"vt": "str"
					},
					{
						"t": "eq",
						"v": "Under 12 months",
						"vt": "str"
					}
				],
				"checkall": "true",
				"repair": false,
				"outputs": 2,
				"x": 900,
				"y": 180,
				"wires": [
					[
						"7256956e0c44fbb1"
					],
					[
						"27a13769faa55324"
					]
				]
			},
			{
				"id": "7256956e0c44fbb1",
				"type": "summary",
				"z": "efb40176baf7f7da",
				"name": "New rapid test for child immediately",
				"x": 1150,
				"y": 140,
				"wires": [
					[
						"e01866a4fa99af14"
					]
				],
				"info": "<h1>New rapid test for child immediately</h1>"
			},
			{
				"id": "e01866a4fa99af14",
				"type": "switch-manual",
				"z": "efb40176baf7f7da",
				"name": "Child status",
				"property": "payload",
				"propertyType": "msg",
				"rules": [
					{
						"t": "eq",
						"v": "Child Positive",
						"vt": "str"
					},
					{
						"t": "eq",
						"v": "Child Negative",
						"vt": "str"
					}
				],
				"checkall": "true",
				"repair": false,
				"outputs": 2,
				"x": 1410,
				"y": 140,
				"wires": [
					[
						"ab531c90ab8351f9"
					],
					[
						"7ff24bb394a3979e"
					]
				]
			},
			{
				"id": "ab531c90ab8351f9",
				"type": "summary",
				"z": "efb40176baf7f7da",
				"name": "Confirmatory DNA-PCR",
				"x": 1630,
				"y": 120,
				"wires": [
					[
						"b65d346e234e75fa"
					]
				],
				"info": "<h1>Confirmatory DNA-PCR</h1>"
			},
			{
				"id": "b65d346e234e75fa",
				"type": "summary",
				"z": "efb40176baf7f7da",
				"name": "Start ART without delay",
				"x": 1890,
				"y": 120,
				"wires": [
					[
						"1586eac888d71f72"
					]
				],
				"info": "<h1>Start ART without delay</h1>"
			},
			{
				"id": "1586eac888d71f72",
				"type": "summary",
				"z": "efb40176baf7f7da",
				"name": "No scheduled fup testing",
				"x": 2150,
				"y": 120,
				"wires": [
					[
						"c50f44b94d51c49f"
					]
				],
				"info": "<h1>No scheduled fup testing</h1>"
			},
			{
				"id": "c50f44b94d51c49f",
				"type": "case-end",
				"z": "efb40176baf7f7da",
				"name": "",
				"x": 2360,
				"y": 120,
				"wires": []
			},
			{
				"id": "7ff24bb394a3979e",
				"type": "summary",
				"z": "efb40176baf7f7da",
				"name": "Enroll child in HCC",
				"x": 1610,
				"y": 160,
				"wires": [
					[
						"32e975e11f026e3a"
					]
				],
				"info": "<h1>Enroll child in HCC</h1>"
			},
			{
				"id": "32e975e11f026e3a",
				"type": "summary",
				"z": "efb40176baf7f7da",
				"name": "Rapid test at age 24 months",
				"x": 2160,
				"y": 160,
				"wires": [
					[
						"aa4255dfc141e105"
					]
				],
				"info": "<h1>Rapid test at age 24 months</h1>"
			},
			{
				"id": "aa4255dfc141e105",
				"type": "case-end",
				"z": "efb40176baf7f7da",
				"name": "",
				"x": 2380,
				"y": 160,
				"wires": []
			},
			{
				"id": "27a13769faa55324",
				"type": "summary",
				"z": "efb40176baf7f7da",
				"name": "Enroll child in HCC",
				"x": 1090,
				"y": 200,
				"wires": [
					[
						"090084675a47846f"
					]
				],
				"info": "<h1>Enroll child in HCC</h1>"
			},
			{
				"id": "090084675a47846f",
				"type": "summary",
				"z": "efb40176baf7f7da",
				"name": "DNA-PCR as soon as possible",
				"x": 1350,
				"y": 200,
				"wires": [
					[
						"7d41ca46045ee621"
					]
				],
				"info": "<h1>DNA-PCR as soon as possible</h1>"
			},
			{
				"id": "7d41ca46045ee621",
				"type": "summary",
				"z": "efb40176baf7f7da",
				"name": "Rapid test at age 12 months",
				"x": 1640,
				"y": 200,
				"wires": [
					[
						"32e975e11f026e3a"
					]
				],
				"info": "<h1>Rapid test at age 12 months</h1>"
			},
			{
				"id": "3d12f1490d54f79c",
				"type": "switch-manual",
				"z": "efb40176baf7f7da",
				"name": "Child status",
				"property": "payload",
				"propertyType": "msg",
				"rules": [
					{
						"t": "eq",
						"v": "Child sick",
						"vt": "str"
					},
					{
						"t": "eq",
						"v": "Child healthy",
						"vt": "str"
					}
				],
				"checkall": "true",
				"repair": false,
				"outputs": 2,
				"x": 410,
				"y": 340,
				"wires": [
					[
						"e02df7d74ecc91d7"
					],
					[
						"d8f6977adafe7a61"
					]
				]
			},
			{
				"id": "e02df7d74ecc91d7",
				"type": "summary",
				"z": "efb40176baf7f7da",
				"name": "Rapid test (serial) for child",
				"x": 630,
				"y": 300,
				"wires": [
					[
						"76cb54bd8b675df2"
					]
				],
				"info": "<h1> Rapid test (serial) for child</h1>"
			},
			{
				"id": "76cb54bd8b675df2",
				"type": "switch-manual",
				"z": "efb40176baf7f7da",
				"name": "Child status",
				"property": "payload",
				"propertyType": "msg",
				"rules": [
					{
						"t": "eq",
						"v": "Child Positive",
						"vt": "str"
					},
					{
						"t": "eq",
						"v": "Child Negative",
						"vt": "str"
					}
				],
				"checkall": "true",
				"repair": false,
				"outputs": 2,
				"x": 850,
				"y": 300,
				"wires": [
					[
						"2b8d105ed9132348"
					],
					[
						"8b1c8ad088d479cd"
					]
				]
			},
			{
				"id": "2b8d105ed9132348",
				"type": "switch-manual",
				"z": "efb40176baf7f7da",
				"name": "Recent",
				"property": "payload",
				"propertyType": "msg",
				"rules": [
					{
						"t": "eq",
						"v": "Under 12 months",
						"vt": "str"
					},
					{
						"t": "eq",
						"v": "12 months +",
						"vt": "str"
					}
				],
				"checkall": "true",
				"repair": false,
				"outputs": 2,
				"x": 1020,
				"y": 280,
				"wires": [
					[
						"b708d40ca9c8c78b"
					],
					[
						"2e383199c450d035"
					]
				]
			},
			{
				"id": "b708d40ca9c8c78b",
				"type": "switch-manual",
				"z": "efb40176baf7f7da",
				"name": "PSHD",
				"property": "payload",
				"propertyType": "msg",
				"rules": [
					{
						"t": "eq",
						"v": "No signs for PSHD",
						"vt": "str"
					},
					{
						"t": "eq",
						"v": "Signs for PSHD",
						"vt": "str"
					}
				],
				"checkall": "true",
				"repair": false,
				"outputs": 2,
				"x": 1170,
				"y": 260,
				"wires": [
					[
						"27a13769faa55324"
					],
					[
						"2e383199c450d035"
					]
				]
			},
			{
				"id": "2e383199c450d035",
				"type": "summary",
				"z": "efb40176baf7f7da",
				"name": "Confirmatory DNA-PCR",
				"x": 1370,
				"y": 280,
				"wires": [
					[
						"b083521daa23ed0f"
					]
				],
				"info": "<h1>Confirmatory DNA-PCR</h1>"
			},
			{
				"id": "b083521daa23ed0f",
				"type": "summary",
				"z": "efb40176baf7f7da",
				"name": "Start ART without delay",
				"x": 1630,
				"y": 280,
				"wires": [
					[
						"4096854d9fc07cb5"
					]
				],
				"info": "<h1>Start ART without delay</h1>"
			},
			{
				"id": "4096854d9fc07cb5",
				"type": "summary",
				"z": "efb40176baf7f7da",
				"name": "No scheduled fup testing",
				"x": 1890,
				"y": 280,
				"wires": [
					[
						"bd23c446dc5e47a4"
					]
				],
				"info": "<h1>No scheduled fup testing</h1>"
			},
			{
				"id": "bd23c446dc5e47a4",
				"type": "case-end",
				"z": "efb40176baf7f7da",
				"name": "",
				"x": 2100,
				"y": 280,
				"wires": []
			},
			{
				"id": "8b1c8ad088d479cd",
				"type": "summary",
				"z": "efb40176baf7f7da",
				"name": "Investigate further",
				"x": 1050,
				"y": 340,
				"wires": [
					[
						"ec916ee52f9a142b"
					]
				],
				"info": "<h1>Investigate further</h1>"
			},
			{
				"id": "ec916ee52f9a142b",
				"type": "case-end",
				"z": "efb40176baf7f7da",
				"name": "",
				"x": 1240,
				"y": 340,
				"wires": []
			},
			{
				"id": "d8f6977adafe7a61",
				"type": "summary",
				"z": "efb40176baf7f7da",
				"name": "Continue regular U5 visit",
				"x": 630,
				"y": 400,
				"wires": [
					[
						"8f0d10d0129179d3"
					]
				],
				"info": "<h1>Continue regular U5 visit</h1>"
			},
			{
				"id": "8f0d10d0129179d3",
				"type": "case-end",
				"z": "efb40176baf7f7da",
				"name": "",
				"x": 840,
				"y": 400,
				"wires": []
			},
			{
				"id": "d710c7f5.b1e898",
				"type": "register-patient",
				"z": "2297acf6.e98c64",
				"name": "Register Patient",
				"x": 140,
				"y": 40,
				"wires": [
					[
						"89f6c852.edac68"
					]
				]
			},
			{
				"id": "19d5e2b3.2f69cd",
				"type": "question-select",
				"z": "2297acf6.e98c64",
				"name": "Duration of Illness",
				"label": "",
				"scope": "encounter",
				"key": "",
				"behavior": "single",
				"devices": [
					{
						"sid": "Less than or equal to 2 days"
					},
					{
						"sid": "2-15 days"
					},
					{
						"sid": "16-30 days"
					},
					{
						"sid": "Over 30 days"
					},
					{
						"sid": "Unknown"
					}
				],
				"x": 190,
				"y": 300,
				"wires": [
					[
						"3a1ccd69.17c732"
					]
				]
			},
			{
				"id": "3a1ccd69.17c732",
				"type": "question-select",
				"z": "2297acf6.e98c64",
				"name": "Conscious",
				"label": "",
				"scope": "encounter",
				"key": "",
				"behavior": "single",
				"devices": [
					{
						"sid": "Yes"
					},
					{
						"sid": "No"
					},
					{
						"sid": "Unknown"
					}
				],
				"x": 170,
				"y": 340,
				"wires": [
					[
						"328c642.c0c819c"
					]
				]
			},
			{
				"id": "328c642.c0c819c",
				"type": "question-select",
				"z": "2297acf6.e98c64",
				"name": "Anemia",
				"label": "",
				"scope": "encounter",
				"key": "",
				"behavior": "",
				"devices": [
					{
						"sid": "Present"
					},
					{
						"sid": "Absent"
					},
					{
						"sid": "Unknown"
					}
				],
				"x": 160,
				"y": 380,
				"wires": [
					[
						"aec8f74d.d475d8"
					]
				]
			},
			{
				"id": "d74069dd.11bc68",
				"type": "summary",
				"z": "2297acf6.e98c64",
				"name": "Show calculated birthdate",
				"x": 560,
				"y": 160,
				"wires": [
					[
						"dd7dc492.d24e78"
					]
				],
				"info": "<h1>Birthdate range</h1> <h3>Start: <span id='range-start'></span> <h3>End: <span id='range-end'></span>  <script> $('#range-start').text(currentPatient.birthdate_start); $('#range-end').text(currentPatient.birthdate_end); </script> "
			},
			{
				"id": "aec8f74d.d475d8",
				"type": "question-select",
				"z": "2297acf6.e98c64",
				"name": "Convulsions",
				"label": "",
				"scope": "encounter",
				"key": "",
				"behavior": "",
				"devices": [
					{
						"sid": "Present"
					},
					{
						"sid": "Absent"
					},
					{
						"sid": "Unknown"
					}
				],
				"x": 310,
				"y": 380,
				"wires": [
					[
						"5c859dc3.f75d74"
					]
				]
			},
			{
				"id": "5c859dc3.f75d74",
				"type": "question-select",
				"z": "2297acf6.e98c64",
				"name": "Cough or Difficulty Breathing (CDB)",
				"label": "",
				"scope": "encounter",
				"key": "",
				"behavior": "",
				"devices": [
					{
						"sid": "Present"
					},
					{
						"sid": "Absent"
					},
					{
						"sid": "Unknown"
					}
				],
				"x": 540,
				"y": 380,
				"wires": [
					[
						"6e00a139.2d646"
					]
				]
			},
			{
				"id": "6e00a139.2d646",
				"type": "question-select",
				"z": "2297acf6.e98c64",
				"name": "Diarrhea",
				"label": "",
				"scope": "encounter",
				"key": "",
				"behavior": "",
				"devices": [
					{
						"sid": "Present"
					},
					{
						"sid": "Absent"
					},
					{
						"sid": "Unknown"
					}
				],
				"x": 160,
				"y": 420,
				"wires": [
					[
						"2e3cda3a.45c256"
					]
				]
			},
			{
				"id": "2e3cda3a.45c256",
				"type": "question-select",
				"z": "2297acf6.e98c64",
				"name": "History of Fever",
				"label": "",
				"scope": "encounter",
				"key": "",
				"behavior": "",
				"devices": [
					{
						"sid": "Present"
					},
					{
						"sid": "Absent"
					},
					{
						"sid": "Unknown"
					}
				],
				"x": 320,
				"y": 420,
				"wires": [
					[
						"6eefc85e.3836c8"
					]
				]
			},
			{
				"id": "6eefc85e.3836c8",
				"type": "question-select",
				"z": "2297acf6.e98c64",
				"name": "Fever (>37.5 C)",
				"label": "",
				"scope": "encounter",
				"key": "",
				"behavior": "",
				"devices": [
					{
						"sid": "Present"
					},
					{
						"sid": "Absent"
					},
					{
						"sid": "Unknown"
					}
				],
				"x": 500,
				"y": 420,
				"wires": [
					[
						"79942273.148c9c"
					]
				]
			},
			{
				"id": "79942273.148c9c",
				"type": "question-select",
				"z": "2297acf6.e98c64",
				"name": "Lethargie",
				"label": "",
				"scope": "encounter",
				"key": "",
				"behavior": "",
				"devices": [
					{
						"sid": "Present"
					},
					{
						"sid": "Absent"
					},
					{
						"sid": "Unknown"
					}
				],
				"x": 160,
				"y": 460,
				"wires": [
					[
						"f75ec5c0.52e9c8"
					]
				]
			},
			{
				"id": "f75ec5c0.52e9c8",
				"type": "question-select",
				"z": "2297acf6.e98c64",
				"name": "Malnutrition",
				"label": "",
				"scope": "encounter",
				"key": "",
				"behavior": "",
				"devices": [
					{
						"sid": "Present"
					},
					{
						"sid": "Absent"
					},
					{
						"sid": "Unknown"
					}
				],
				"x": 310,
				"y": 460,
				"wires": [
					[
						"fbdd36ea.334ec8"
					]
				]
			},
			{
				"id": "fbdd36ea.334ec8",
				"type": "question-select",
				"z": "2297acf6.e98c64",
				"name": "Unable to feed",
				"label": "",
				"scope": "encounter",
				"key": "",
				"behavior": "",
				"devices": [
					{
						"sid": "Present"
					},
					{
						"sid": "Absent"
					},
					{
						"sid": "Unknown"
					}
				],
				"x": 480,
				"y": 460,
				"wires": [
					[
						"43c8349f.53bb5c"
					]
				]
			},
			{
				"id": "43c8349f.53bb5c",
				"type": "question-select",
				"z": "2297acf6.e98c64",
				"name": "Vomiting",
				"label": "",
				"scope": "encounter",
				"key": "",
				"behavior": "",
				"devices": [
					{
						"sid": "Present"
					},
					{
						"sid": "Absent"
					},
					{
						"sid": "Unknown"
					}
				],
				"x": 640,
				"y": 460,
				"wires": [
					[
						"4f026bb8.e9fa54"
					]
				]
			},
			{
				"id": "8e24c976.e51638",
				"type": "question-select",
				"z": "2297acf6.e98c64",
				"name": "Age",
				"label": "",
				"scope": "demographic",
				"key": "",
				"behavior": "single",
				"devices": [
					{
						"sid": "Less than 2 months"
					},
					{
						"sid": "2-12 months"
					},
					{
						"sid": "13-24 months"
					},
					{
						"sid": "25-60 months"
					},
					{
						"sid": "Over 60 months"
					},
					{
						"sid": "Unknown"
					}
				],
				"x": 150,
				"y": 160,
				"wires": [
					[
						"90ba20ce.f4aa7"
					]
				]
			},
			{
				"id": "dd7dc492.d24e78",
				"type": "create-patient",
				"z": "2297acf6.e98c64",
				"name": "",
				"x": 140,
				"y": 200,
				"wires": [
					[
						"2e150ef5.1d0c42"
					]
				]
			},
			{
				"id": "4f026bb8.e9fa54",
				"type": "create-encounter-end",
				"z": "2297acf6.e98c64",
				"name": "",
				"x": 170,
				"y": 500,
				"wires": []
			},
			{
				"id": "85e4ecd2.055be",
				"type": "patients-queue",
				"z": "2297acf6.e98c64",
				"name": "Waiting for Tests",
				"queueName": "first",
				"queueDateFilter": "",
				"label": "",
				"encounterType": "second",
				"rowcontent": "'<option class=emr-select-option value=' + '' + key + '>'  + entry.givenname + ' - '  + entry.Age_text + ' - ' + entry['Health ID']  + '</option>'",
				"x": 140,
				"y": 560,
				"wires": [
					[
						"4e0df014.ab708"
					]
				]
			},
			{
				"id": "f7b8d06e.c27be",
				"type": "patients-queue",
				"z": "2297acf6.e98c64",
				"name": "Waiting for Results",
				"queueName": "second",
				"queueDateFilter": "",
				"label": "",
				"encounterType": "third",
				"rowcontent": "'<option class=emr-select-option value=' + '' + key + '>'  + entry.givenname + ' - '  + entry.Age_text + ' - ' + entry['Health ID']  + '</option>'",
				"x": 150,
				"y": 600,
				"wires": [
					[
						"9b0c01e4.3d6b6"
					]
				]
			},
			{
				"id": "322b709e.ee2fe",
				"type": "create-encounter-end",
				"z": "2297acf6.e98c64",
				"name": "",
				"x": 530,
				"y": 560,
				"wires": []
			},
			{
				"id": "958eabf3.adbdf8",
				"type": "create-encounter-end",
				"z": "2297acf6.e98c64",
				"name": "",
				"x": 530,
				"y": 600,
				"wires": []
			},
			{
				"id": "cbe77f00.95673",
				"type": "question-primitive",
				"z": "2297acf6.e98c64",
				"name": "Name",
				"label": "",
				"scope": "demographic",
				"key": "givenname",
				"datatype": "string",
				"optional": "",
				"x": 150,
				"y": 120,
				"wires": [
					[
						"8e24c976.e51638"
					]
				]
			},
			{
				"id": "89f6c852.edac68",
				"type": "question-primitive",
				"z": "2297acf6.e98c64",
				"name": "Health ID",
				"label": "",
				"scope": "demographic",
				"key": "",
				"datatype": "string",
				"optional": true,
				"x": 160,
				"y": 80,
				"wires": [
					[
						"cbe77f00.95673"
					]
				]
			},
			{
				"id": "90ba20ce.f4aa7",
				"type": "function",
				"z": "2297acf6.e98c64",
				"name": "calc birthdate range",
				"func": "var start = new Date(); var end = new Date();  switch (currentPatient.Age_val) {     case '0':         start.setMonth(start.getMonth() - 2);         end = '';         break;     case '1':         start.setMonth(start.getMonth() - 12);         end.setMonth(end.getMonth() - 2);         break;     case '2':         start.setMonth(start.getMonth() - 24);         end.setMonth(end.getMonth() - 13);         break;     case '3':         start.setMonth(start.getMonth() - 60);         end.setMonth(end.getMonth() - 25);         break;     case '4':         start = '';         end.setMonth(end.getMonth() - 60);         break;     case '5':         start = 'unknown';         end = 'unknown';     default:         start = 'error';         end = 'error';         break; }  currentPatient['birthdate_start']= start; currentPatient['birthdate_end']= end;  updateCurrentPatient(currentPatient); ",
				"outputs": 1,
				"noerr": 0,
				"x": 320,
				"y": 160,
				"wires": [
					[
						"d74069dd.11bc68"
					]
				]
			},
			{
				"id": "2e150ef5.1d0c42",
				"type": "set-encountertype",
				"z": "2297acf6.e98c64",
				"name": "",
				"encounterType": "first",
				"x": 150,
				"y": 260,
				"wires": [
					[
						"19d5e2b3.2f69cd"
					]
				]
			},
			{
				"id": "28d4d88.067c828",
				"type": "find-patient",
				"z": "2297acf6.e98c64",
				"name": "Browse all patients",
				"includename": "",
				"includeidentifier": "",
				"program": "",
				"expression": "",
				"rowcontent": "'<option class=emr-select-option value=' + '' + key + '>'  + entry.givenname + ' - '  + entry.Age_text + ' - ' + entry['Health ID']  + '</option>'",
				"x": 150,
				"y": 640,
				"wires": [
					[
						"5a4bc667.de1008"
					]
				]
			},
			{
				"id": "5a4bc667.de1008",
				"type": "end-flow",
				"z": "2297acf6.e98c64",
				"name": "",
				"x": 340,
				"y": 640,
				"wires": []
			},
			{
				"id": "75931b8b.30a314",
				"type": "careflow",
				"z": "2297acf6.e98c64",
				"careflow_runtime": "7bf38ac1.088444",
				"x": 980,
				"y": 40,
				"wires": []
			},
			{
				"id": "9b0c01e4.3d6b6",
				"type": "question-select",
				"z": "2297acf6.e98c64",
				"name": "Result",
				"label": "",
				"scope": "encounter",
				"key": "",
				"behavior": "single",
				"devices": [
					{
						"sid": "positive"
					},
					{
						"sid": "negative"
					},
					{
						"sid": "inconclusive"
					},
					{
						"sid": "invalid / unknown"
					}
				],
				"x": 330,
				"y": 600,
				"wires": [
					[
						"958eabf3.adbdf8"
					]
				]
			},
			{
				"id": "4e0df014.ab708",
				"type": "question-select",
				"z": "2297acf6.e98c64",
				"name": "Tested",
				"label": "",
				"scope": "encounter",
				"key": "",
				"behavior": "single",
				"devices": [
					{
						"sid": "yes"
					},
					{
						"sid": "no"
					}
				],
				"x": 330,
				"y": 560,
				"wires": [
					[
						"322b709e.ee2fe"
					]
				]
			},
			{
				"id": "21283cd9.7a7004",
				"type": "patients-queue",
				"z": "5d901e35.d089c",
				"name": "Checked in Patients",
				"queueName": "all",
				"queueDateFilter": "",
				"label": "",
				"encounterType": "",
				"x": 230,
				"y": 80,
				"wires": [
					[
						"d9e76286.a465c"
					]
				]
			},
			{
				"id": "bbf0358e.d46228",
				"type": "end-flow",
				"z": "5d901e35.d089c",
				"name": "",
				"x": 660,
				"y": 400,
				"wires": []
			},
			{
				"id": "d9e76286.a465c",
				"type": "question-primitive",
				"z": "5d901e35.d089c",
				"name": "Height",
				"label": "",
				"scope": "encounter",
				"key": "",
				"datatype": "integer",
				"optional": "",
				"x": 230,
				"y": 120,
				"wires": [
					[
						"269c4889.efc128"
					]
				]
			},
			{
				"id": "269c4889.efc128",
				"type": "question-primitive",
				"z": "5d901e35.d089c",
				"name": "Weight",
				"label": "",
				"scope": "encounter",
				"key": "",
				"datatype": "integer",
				"optional": "",
				"x": 230,
				"y": 160,
				"wires": [
					[
						"c2659f0.a04e46"
					]
				]
			},
			{
				"id": "6944cfb4.74d44",
				"type": "question-primitive",
				"z": "5d901e35.d089c",
				"name": "MUAC",
				"label": "",
				"scope": "encounter",
				"key": "",
				"datatype": "integer",
				"optional": "",
				"x": 230,
				"y": 400,
				"wires": [
					[
						"bbf0358e.d46228"
					]
				]
			},
			{
				"id": "29f52933.7f1b06",
				"type": "function",
				"z": "5d901e35.d089c",
				"name": "Calc BMI",
				"func": "currentEncounter.bmi =    10000 *   Number(currentEncounter.Weight) /   (Number(currentEncounter.Height) * Number(currentEncounter.Height));",
				"outputs": 1,
				"noerr": 0,
				"x": 620,
				"y": 160,
				"wires": [
					[
						"60b50cb3.79b684"
					]
				]
			},
			{
				"id": "c2659f0.a04e46",
				"type": "switch",
				"z": "5d901e35.d089c",
				"name": "under 5?",
				"property": "payload",
				"propertyType": "msg",
				"rules": [
					{
						"t": "eq",
						"v": "no",
						"vt": "str"
					},
					{
						"t": "eq",
						"v": "yes",
						"vt": "str"
					}
				],
				"checkall": "true",
				"repair": false,
				"outputs": 2,
				"x": 460,
				"y": 160,
				"wires": [
					[
						"29f52933.7f1b06"
					],
					[
						"60b50cb3.79b684"
					]
				]
			},
			{
				"id": "956a92cf.98b4c",
				"type": "question-primitive",
				"z": "5d901e35.d089c",
				"name": "BP Systolic",
				"label": "",
				"scope": "encounter",
				"key": "",
				"datatype": "integer",
				"optional": "",
				"x": 250,
				"y": 320,
				"wires": [
					[
						"93e8b788.ba37d8"
					]
				]
			},
			{
				"id": "93e8b788.ba37d8",
				"type": "question-primitive",
				"z": "5d901e35.d089c",
				"name": "BP Diastolic",
				"label": "",
				"scope": "encounter",
				"key": "",
				"datatype": "integer",
				"optional": "",
				"x": 430,
				"y": 320,
				"wires": [
					[
						"72ce0f46.1223d"
					]
				]
			},
			{
				"id": "60b50cb3.79b684",
				"type": "question-primitive",
				"z": "5d901e35.d089c",
				"name": "Temperature",
				"label": "",
				"scope": "encounter",
				"key": "",
				"datatype": "integer",
				"optional": "",
				"x": 250,
				"y": 200,
				"wires": [
					[
						"fd6a8a17.abaeb8"
					]
				]
			},
			{
				"id": "fd6a8a17.abaeb8",
				"type": "question-primitive",
				"z": "5d901e35.d089c",
				"name": "Pulse",
				"label": "",
				"scope": "encounter",
				"key": "",
				"datatype": "integer",
				"optional": "",
				"x": 230,
				"y": 240,
				"wires": [
					[
						"784eb13e.53e"
					]
				]
			},
			{
				"id": "784eb13e.53e",
				"type": "question-primitive",
				"z": "5d901e35.d089c",
				"name": "Respiratory Rate",
				"label": "",
				"scope": "encounter",
				"key": "",
				"datatype": "integer",
				"optional": "",
				"x": 270,
				"y": 280,
				"wires": [
					[
						"956a92cf.98b4c"
					]
				]
			},
			{
				"id": "72ce0f46.1223d",
				"type": "question-primitive",
				"z": "5d901e35.d089c",
				"name": "Oxygen saturation",
				"label": "",
				"scope": "encounter",
				"key": "",
				"datatype": "integer",
				"optional": "",
				"x": 270,
				"y": 360,
				"wires": [
					[
						"133ee0a7.8a15ff"
					]
				]
			},
			{
				"id": "133ee0a7.8a15ff",
				"type": "switch",
				"z": "5d901e35.d089c",
				"name": "under 13?",
				"property": "payload",
				"propertyType": "msg",
				"rules": [
					{
						"t": "eq",
						"v": "no",
						"vt": "str"
					},
					{
						"t": "eq",
						"v": "yes",
						"vt": "str"
					}
				],
				"checkall": "true",
				"repair": false,
				"outputs": 2,
				"x": 460,
				"y": 360,
				"wires": [
					[
						"bbf0358e.d46228"
					],
					[
						"6944cfb4.74d44"
					]
				]
			},
			{
				"id": "ca17b30a.bbaf1",
				"type": "find-patient",
				"z": "5d901e35.d089c",
				"name": "",
				"includename": "",
				"includeidentifier": "",
				"program": "",
				"expression": "",
				"rowcontent": "",
				"x": 470,
				"y": 80,
				"wires": [
					[
						"d9e76286.a465c"
					]
				]
			},
			{
				"id": "fcd5534a.873ad",
				"type": "Blockly",
				"z": "5d901e35.d089c",
				"d": true,
				"language": "en",
				"func": "var bmi, currentPatient_age, weight, height;   if (currentPatient_age >= 18) {   bmi = weight / (height * height); } ",
				"outputs": 1,
				"name": "Adult BMI",
				"x": 360,
				"y": 560,
				"wires": [
					[]
				]
			},
			{
				"id": "2a327b39.bc8224",
				"type": "patients-queue",
				"z": "e720fdd.1c9ee",
				"name": "Checked in Patients",
				"queueName": "all",
				"queueDateFilter": "",
				"label": "",
				"encounterType": "",
				"x": 230,
				"y": 120,
				"wires": [
					[
						"937cc2de.c4aca"
					]
				]
			},
			{
				"id": "2a9c481e.8dc158",
				"type": "end-flow",
				"z": "e720fdd.1c9ee",
				"name": "",
				"x": 640,
				"y": 400,
				"wires": []
			},
			{
				"id": "97dd765e.7a0248",
				"type": "question-primitive",
				"z": "e720fdd.1c9ee",
				"name": "MUAC",
				"label": "",
				"scope": "encounter",
				"key": "",
				"datatype": "integer",
				"optional": "",
				"x": 230,
				"y": 400,
				"wires": [
					[
						"2a9c481e.8dc158"
					]
				]
			},
			{
				"id": "3c942ee5.31c1a2",
				"type": "function",
				"z": "e720fdd.1c9ee",
				"name": "Calc BMI",
				"func": "currentEncounter.bmi =    10000 *   Number(currentEncounter.Weight) /   (Number(currentEncounter.Height) * Number(currentEncounter.Height));",
				"outputs": 1,
				"noerr": 0,
				"x": 620,
				"y": 160,
				"wires": [
					[
						"e9aefa82.2eefa8"
					]
				]
			},
			{
				"id": "712149b5.5f67f8",
				"type": "switch",
				"z": "e720fdd.1c9ee",
				"name": "under 5?",
				"property": "payload",
				"propertyType": "msg",
				"rules": [
					{
						"t": "eq",
						"v": "no",
						"vt": "str"
					},
					{
						"t": "eq",
						"v": "yes",
						"vt": "str"
					}
				],
				"checkall": "true",
				"repair": false,
				"outputs": 2,
				"x": 460,
				"y": 160,
				"wires": [
					[
						"3c942ee5.31c1a2"
					],
					[
						"e9aefa82.2eefa8"
					]
				]
			},
			{
				"id": "e9aefa82.2eefa8",
				"type": "question-primitive",
				"z": "e720fdd.1c9ee",
				"name": "Temperature",
				"label": "",
				"scope": "encounter",
				"key": "",
				"datatype": "integer",
				"optional": "",
				"x": 250,
				"y": 200,
				"wires": [
					[
						"2b78db1f.b3bad4"
					]
				]
			},
			{
				"id": "2b78db1f.b3bad4",
				"type": "question-primitive",
				"z": "e720fdd.1c9ee",
				"name": "Pulse",
				"label": "",
				"scope": "encounter",
				"key": "",
				"datatype": "integer",
				"optional": "",
				"x": 230,
				"y": 240,
				"wires": [
					[
						"ee753259.58701"
					]
				]
			},
			{
				"id": "ee753259.58701",
				"type": "question-primitive",
				"z": "e720fdd.1c9ee",
				"name": "Respiratory Rate",
				"label": "",
				"scope": "encounter",
				"key": "",
				"datatype": "integer",
				"optional": "",
				"x": 270,
				"y": 280,
				"wires": [
					[
						"76d50390.69c87c"
					]
				]
			},
			{
				"id": "fb98787d.304e88",
				"type": "question-primitive",
				"z": "e720fdd.1c9ee",
				"name": "Oxygen saturation",
				"label": "",
				"scope": "encounter",
				"key": "",
				"datatype": "integer",
				"optional": "",
				"x": 270,
				"y": 360,
				"wires": [
					[
						"f08df5ca.d0dc48"
					]
				]
			},
			{
				"id": "f08df5ca.d0dc48",
				"type": "switch",
				"z": "e720fdd.1c9ee",
				"name": "under 13?",
				"property": "payload",
				"propertyType": "msg",
				"rules": [
					{
						"t": "eq",
						"v": "no",
						"vt": "str"
					},
					{
						"t": "eq",
						"v": "yes",
						"vt": "str"
					}
				],
				"checkall": "true",
				"repair": false,
				"outputs": 2,
				"x": 460,
				"y": 360,
				"wires": [
					[
						"2a9c481e.8dc158"
					],
					[
						"97dd765e.7a0248"
					]
				]
			},
			{
				"id": "2601305b.036f8",
				"type": "find-patient",
				"z": "e720fdd.1c9ee",
				"name": "",
				"includename": "",
				"includeidentifier": "",
				"program": "",
				"expression": "",
				"rowcontent": "",
				"x": 470,
				"y": 120,
				"wires": [
					[
						"937cc2de.c4aca"
					]
				]
			},
			{
				"id": "937cc2de.c4aca",
				"type": "height-weight",
				"z": "e720fdd.1c9ee",
				"name": "",
				"label": "",
				"keyHeight": "Height",
				"keyWeight": "Weight",
				"x": 260,
				"y": 160,
				"wires": [
					[
						"712149b5.5f67f8"
					]
				]
			},
			{
				"id": "76d50390.69c87c",
				"type": "blood-pressure",
				"z": "e720fdd.1c9ee",
				"name": "",
				"label": "",
				"key": "bp",
				"x": 260,
				"y": 320,
				"wires": [
					[
						"fb98787d.304e88"
					]
				]
			}
		]
		
	`;
		 // console.log('YYY abc ' + abc);
		jsonFlow = $.parseJSON(abc);
});

function toUpperCaseFirstLetter(string)  {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

function getUrlParam(param) {
	let searchParams = new URLSearchParams(window.location.search);
	return searchParams.get(param);
}

function formatDate(date) {
	const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
	return ("0" + date.getDate()).slice(-2) + "-" + monthNames[date.getMonth()] + "-" + date.getFullYear();
}

function labelFor(node) {
	if (node.label === undefined || node.label.trim() === '') {
		if (node.name === undefined || node.name.trim() === '') {
			return node.type;
		}
		return node.name;
	}
	return node.label;
}

function keyFor(node) {
	if (node.key === undefined || node.key.trim() === '') {
		if (node.name === undefined || node.name.trim() === '') {
			return node.type;
		}
		return node.name;
	} else {
		return node.key;
	}
}

// ---------------------------------------------------------
// common onload stuff for pages

function processPageDemographicAttribute() {
	$('#alphapad').addClass('d-none');
	$('#keypad').addClass('d-none');
	$('#datepad').addClass('d-none');
	$('#booleanpad').addClass('d-none');
	let nodeid = getUrlParam('nodeid');
 	var node = nodeById(jsonFlow, nodeid);
	$('#input-label').contents().last().replaceWith(node.label);
	switch (node.datatype) {
		case 'decimal':
			$('#keypad-dot').prop('disabled', false);
			$('#keypad').removeClass('d-none');
			break;
		case 'integer':
			$('#keypad-dot').prop('disabled', true);
			$('#keypad').removeClass('d-none');
			break;
		case 'text':
		case 'string':
			$('#alphapad').removeClass('d-none');
			break;
		case 'date':
		case 'time':
		case 'dateTime':
			$('#datepad').removeClass('d-none');
			break;
		case 'boolean':
			$('#booleanpad').removeClass('d-none');
			break;
	}
}

// ---------------------------------------------------------
// common button handlers

function defaultButtonAlphapad(e) {
	if (e.target.id.startsWith("alphapad-bksp")) {
		document.getElementById('input').value = document.getElementById('input').value.substring(0, document.getElementById('input').value.length-1);
	} else if (e.target.id.startsWith("alphapad-dash")) {
		document.getElementById('input').value += '-';
	} else if (e.target.id.startsWith("alphapad-quote")) {
		document.getElementById('input').value += '\'';
	} else if (e.target.id.startsWith("alphapad-space")) {
		document.getElementById('input').value += ' ';
	} else if (e.target.id.startsWith("alphapad-")) {
		document.getElementById('input').value += e.target.id.substring(9);
		document.getElementById('input').value = toUpperCaseFirstLetter(document.getElementById('input').value);
	}
}

function defaultButtonKeypad(e) {
	if (e.target.id.startsWith("keypad-bksp")) {
		document.getElementById('input').value = document.getElementById('input').value.substring(0, document.getElementById('input').value.length-1);
	} else if (e.target.id.startsWith("keypad-dot")) {
		document.getElementById('input').value += '.';
	} else if (e.target.id.startsWith("keypad-")) {
		document.getElementById('input').value += e.target.id.substring(7);
	}
}

function defaultButtonDatepad(e) {
	if (e.target.id.startsWith("keypad-bksp")) {
		document.getElementById('year').value = document.getElementById('year').value.substring(0, document.getElementById('year').value.length-1);
	} else if (e.target.id.startsWith("keypad-dot")) {
		document.getElementById('year').value += '.';
	} else if (e.target.id.startsWith("keypad-")) {
		document.getElementById('year').value += e.target.id.substring(7);
	} else if (e.target.id.startsWith("monthpad-")) {
		document.getElementById('month').value = e.target.id.substring(9);
		document.getElementById('input').value = document.getElementById('year').value + '-' + document.getElementById('month').value + '-' + document.getElementById('day').value;
	} else if (e.target.id.startsWith("day-")) {
		document.getElementById('day').value = e.target.id.substring(4);
		document.getElementById('input').value = document.getElementById('year').value + '-' + document.getElementById('month').value + '-' + document.getElementById('day').value;
	}
}

function defaultButtonBooleanpad(e) {
	if (e.target.id.startsWith("booleanpad-yes")) {
		document.getElementById('input').value = 'Yes';
	} else if (e.target.id.startsWith("booleanpad-no")) {
		document.getElementById('input').value = 'No';
	}
}

// ---------------------------------------------------------
// register event handlers
$(function(){
	// change active class based on selection in all list-groups; currently prevents multiselect
	$('.list-group li').click(function(e) {
		e.preventDefault();
		$that = $(this);
		$that.toggleClass('active');
	});
	$('.list-group:not(.multiple) li').click(function(e) {
		e.preventDefault();
		$that = $(this);
		$that.parent().find('li').removeClass('active');
		$that.addClass('active');
		if($('html').is('#page-current-address') || $('html').is('#page-home-address')){
	    // processPageCheckedInPatientsList();
			switch($that.parent()[0].id) {
				case "list-region":
					document.getElementById('input-region').value = e.currentTarget.childNodes[0].innerText;
					break;
				case "list-district":
					document.getElementById('input-district').value = e.currentTarget.childNodes[0].innerText;
					break;
				case "list-ta":
					document.getElementById('input-ta').value = e.currentTarget.childNodes[0].innerText;
					break;
				case "list-village":
					document.getElementById('input-village').value = e.currentTarget.childNodes[0].innerText;
					break;
			}
		}
	});

	// load onload functions if page provides them
	// https://api.jquery.com/jQuery.getScript/
	var pageId = $('html').attr('id');
	// if (pageId.startsWith('page-')) {
	var pageName = pageId.substring(5, pageId.length);
	var onLoadFunctionName = pageName.replace( /-([a-z])/ig, function( all, letter ) {
		return letter.toUpperCase();
	});
	var onLoadFunctionName = onLoadFunctionName[0].toUpperCase() + onLoadFunctionName.slice(1);
	if (eval("typeof " + 'onLoad' + onLoadFunctionName) === 'function') {
		console.log('calling ' + 'onLoad' + onLoadFunctionName);
		// loadCurrentPatient(function() {});
		// loadCurrentEncounter(function() {});
		self['onLoad' + onLoadFunctionName]();
	} else {
		// make sure that at least the header is set
		// loadCurrentPatient(function() {});
		console.log("No onLoad function provided by module " + onLoadFunctionName);
	}
	// if (pageId.startsWith('page-')) {
	// 	pageName = pageId.substring(5, pageId.length);
	// 	$.get("assets/client-js/bricks/" + pageName + ".js")
	// 		.done(function() {
	// 			$.getScript( "assets/client-js/bricks/" + pageName + ".js" )
	// 				.done(function( script, textStatus ) {
	// 					console.log("Loading page-specific script file: " + pageName );
	// 					// processPageFindPatient();
	// 					onLoadFunctionName = pageName.replace( /-([a-z])/ig, function( all, letter ) {
	// 						return letter.toUpperCase();
	// 					});
	// 					onLoadFunctionName = onLoadFunctionName[0].toUpperCase() + onLoadFunctionName.slice(1);
	// 					if (eval("typeof " + 'onLoad' + onLoadFunctionName) === 'function') {
	// 						console.log('calling ' + 'onLoad' + onLoadFunctionName);
	// 						// loadCurrentPatient(function() {});
	// 						// loadCurrentEncounter(function() {});
	// 						self['onLoad' + onLoadFunctionName]();
	// 					} else {
	// 						// make sure that at least the header is set
	// 						// loadCurrentPatient(function() {});
	// 						console.log("No onLoad function provided by module " + onLoadFunctionName);
	// 					}
	// 				})
	// 				.fail(function( jqxhr, settings, exception ) {
	// 					console.log("Loading FAILED for page-specific script file: " + pageName );
	// 				});
	// 			})
	// 		.fail(function() {
	// 			// make sure that at least the header is set
	// 			// loadCurrentPatient(function() {});
	// 			console.log("No page-specific script file found: " + pageName );
	// 		})
	// }

});

// respond to keys pressed
$(document).keypress(function(e) {
	// event.preventDefault();
	if ($('#navigation-next').prop('disabled') === false) {
		if(e.which == 13) {
		// enter pressed
			nextPressed(e);
		}
	};
});

// repsond to buttons clicked
$('.btn').click(function(e) {

	// navigation buttons in footer
	switch (e.currentTarget.id) {
		case "navigation-next":
			nextPressed(e);
			break;
		case "navigation-back":
			// console.log("previous brick: " + window.location.pathname);
			// location = getPreviousBrick(window.location.pathname) + ".html";
			window.history.back();
			break;
		case "navigation-clear":
			// loadCurrentPatient from previous step
			location.reload();
			break;
		case "navigation-finish":
			finishPressed(e);
			break;
		case "navigation-cancel":
			location = 'flow-select.html';
			break;
	}
});

function nextPressed(e) {
	// prepare module specific button handlers
	pageId = $("html")[0].id;
	moduleName = "";
	if (pageId.startsWith('page-')) {
		pageName = pageId.substring(5, pageId.length);
		moduleName = pageName.replace( /-([a-z])/ig, function( all, letter ) {
			return letter.toUpperCase();
		});
		moduleName = moduleName[0].toUpperCase() + moduleName.slice(1);
	}

	let nodeid = getUrlParam('nodeid');
	let stepid = getUrlParam('stepid');
	stepid++;
	let next = nextNode(jsonFlow, nodeById(jsonFlow, nodeid))[0];
	if (typeof next === 'undefined') {
		alert('Missing outgoing connection in workflow definition!');
	}
	// store
	let newUrl = next.type + ".html?stepid=" + stepid + "&nodeid=" + next.id;
	// console.log(newUrl);

	console.log(newUrl + ' ' + eval("typeof " + 'hookNext' + moduleName));
	if (eval("typeof " + 'hookNext' + moduleName) === 'function') {
		console.log('calling ' + 'hookNext' + moduleName);
		self['hookNext' + moduleName](e);
		updateCurrentEncounter(currentEncounter);
		updateCurrentPatient(currentPatient);
	} else {
		console.log("No hookNext function provided by module " + moduleName);
	}

	location= newUrl;
}

function finishPressed(e) {
	pageId = $("html")[0].id;
	moduleName = "";
	if (pageId.startsWith('page-')) {
		pageName = pageId.substring(5, pageId.length);
		moduleName = pageName.replace( /-([a-z])/ig, function( all, letter ) {
			return letter.toUpperCase();
		});
		moduleName = moduleName[0].toUpperCase() + moduleName.slice(1);
	}
	
	console.log(eval("typeof " + 'hookFinish' + moduleName));
	if (eval("typeof " + 'hookFinish' + moduleName) === 'function') {
		console.log('calling ' + 'hookFinish' + moduleName);
		self['hookFinish' + moduleName](e);
		// updateCurrentEncounter(currentEncounter);
		// updateCurrentPatient(currentPatient);
	} else {
		console.log("No hookFinish function provided by module " + moduleName);
	}
	// location = '/';
	// location = 'flow-select.html';

	/*
	// TODO this should move somewhere more appropriate
	if (!jQuery.isEmptyObject(currentEncounter)) { 
		// 'normal encounter'
		$.ajax({
		    type: "POST",
		    url: "/patients/" + currentPatient.id + "/encounters/",
		    // The key needs to match your method's input parameter (case-sensitive).
		    data: JSON.stringify(currentEncounter),
		    contentType: "application/json; charset=utf-8",
		    dataType: "json",
		    success: function(data){
				// alert('Data saved');
				location = 'flow-select.html';
			},
		    error: function(errMsg) {
				console.log("errMsg");
				console.log(JSON.stringify(errMsg));
		        alert(errMsg);
		    }
		});
	}
	location = 'flow-select.html';
	*/
}