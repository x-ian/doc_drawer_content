$('#loginButton').click( function() {
    $.post( '/user/authenticate', $('#loginForm').serialize(), function(data) {
			location = "/";
       },
       'json' // I expect a JSON response
    ).fail(function(data) {
			$('#alert').addClass('alert-danger');
			$('#alert').append(data.responseText);
    });
});
